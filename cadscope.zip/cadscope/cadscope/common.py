"""Shared preprocessing + inference helpers for CADScope."""
import numpy as np
import pandas as pd

from .gene_info import PATHWAYS


def load_counts(path_or_buf) -> pd.DataFrame:
    """Read a raw-count matrix: rows = gene symbols, columns = samples."""
    df = pd.read_csv(path_or_buf, sep=None, engine="python", index_col=0)
    df = df.apply(pd.to_numeric, errors="coerce").dropna(how="all").fillna(0)
    df.index = df.index.astype(str).str.strip().str.upper()
    df = df.groupby(level=0).sum()  # collapse duplicate symbols
    return df


def log_cpm(counts: pd.DataFrame) -> pd.DataFrame:
    """Library-size normalise to CPM, then log2(CPM + 1). Genes x samples."""
    lib = counts.sum(axis=0).replace(0, np.nan)
    return np.log2(counts / lib * 1e6 + 1).fillna(0)


def predict(bundle: dict, counts: pd.DataFrame):
    """Score samples with a trained bundle.

    Returns (probabilities Series, per-gene contribution DataFrame, gene coverage).
    Genes missing from the upload are imputed with the training mean.
    """
    genes = bundle["genes"]
    x = log_cpm(counts).T.reindex(columns=genes)  # samples x genes
    coverage = float(x.notna().any().mean())
    x = x.fillna(pd.Series(bundle["train_means"]))
    pipe = bundle["pipeline"]
    prob = pd.Series(pipe.predict_proba(x.values)[:, 1], index=x.index, name="cad_score")

    scaler, selector, clf = (pipe.named_steps[k] for k in ("scale", "select", "clf"))
    z = scaler.transform(x.values)[:, selector.get_support()]
    sel_genes = np.array(genes)[selector.get_support()]
    contrib = pd.DataFrame(z * clf.coef_[0], index=x.index, columns=sel_genes)
    return prob, contrib, coverage


def risk_tier(p: float) -> str:
    if p < 0.33:
        return "Low"
    if p < 0.66:
        return "Intermediate"
    return "High"


def pathway_summary(contrib_row: pd.Series) -> pd.DataFrame:
    """Sum per-gene contributions into pathway-level signals (annotated genes only)."""
    rows = []
    for pathway, genes in PATHWAYS.items():
        hit = [g for g in genes if g in contrib_row.index]
        if hit:
            rows.append((pathway, float(contrib_row[hit].sum()), ", ".join(hit)))
    return pd.DataFrame(rows, columns=["pathway", "net_contribution", "genes_in_model"]).sort_values(
        "net_contribution", ascending=False
    )
