"""CADScope: RNA-seq based coronary artery disease risk prototype."""
