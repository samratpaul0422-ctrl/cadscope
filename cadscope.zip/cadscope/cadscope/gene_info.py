"""Curated CAD-relevant pathways used to turn per-gene model signal into something a clinician can read.

This is a small, hand-picked annotation (not exhaustive). Extend it freely.
"""

PATHWAYS = {
    "Lipid metabolism & cholesterol transport": [
        "LDLR", "PCSK9", "APOB", "APOE", "APOA1", "ABCA1", "ABCG1", "LPL", "CETP", "SREBF2", "HMGCR",
    ],
    "Inflammation & cytokine signalling": [
        "IL6", "IL1B", "TNF", "CXCL8", "CCL2", "NFKB1", "PTGS2", "IL18", "TLR4", "CRP",
    ],
    "Innate immune / monocyte activation": [
        "CD14", "S100A8", "S100A9", "S100A12", "FCGR3A", "LYZ", "CD68", "MMP9",
    ],
    "Endothelial function & vascular tone": [
        "NOS3", "VCAM1", "ICAM1", "SELE", "EDN1", "KLF2", "KLF4", "VWF",
    ],
    "Thrombosis & coagulation": [
        "F2R", "SERPINE1", "PLAT", "F3", "ITGB3", "GP1BA", "THBD",
    ],
    "Extracellular matrix & plaque remodelling": [
        "MMP2", "MMP3", "MMP9", "TIMP1", "COL1A1", "COL3A1", "FN1", "SPP1",
    ],
    "Oxidative stress & apoptosis": [
        "SOD2", "NFE2L2", "HMOX1", "CASP3", "BCL2", "BAX", "TP53",
    ],
}

# Plain-language meaning + what a clinician might follow up on when a pathway is pushing risk UP.
PATHWAY_ADVICE = {
    "Lipid metabolism & cholesterol transport": (
        "Lipid-handling genes are shifting the score. Consider a full lipid panel (LDL-C, HDL-C, "
        "triglycerides, ApoB, Lp(a)) and review diet / statin eligibility."
    ),
    "Inflammation & cytokine signalling": (
        "Inflammatory signalling is elevated. Consider hs-CRP, review chronic inflammatory "
        "conditions, smoking status, sleep and weight."
    ),
    "Innate immune / monocyte activation": (
        "Monocyte/neutrophil activation signature present, which is linked to active plaque "
        "biology. Correlate with symptoms and standard risk scores."
    ),
    "Endothelial function & vascular tone": (
        "Endothelial dysfunction markers are shifted. Check blood pressure, glucose / HbA1c and "
        "review exercise and salt intake."
    ),
    "Thrombosis & coagulation": (
        "Pro-thrombotic expression pattern. A clinician may consider platelet / coagulation "
        "history and antiplatelet suitability."
    ),
    "Extracellular matrix & plaque remodelling": (
        "Matrix-remodelling genes suggest plaque turnover. Imaging (e.g. CT calcium score) may "
        "add useful context."
    ),
    "Oxidative stress & apoptosis": (
        "Oxidative-stress / cell-death genes are shifted. Lifestyle factors (smoking, diet, "
        "activity) are the main modifiable levers."
    ),
}

GENERAL_PRECAUTIONS = [
    "Do not use this score alone to diagnose or rule out coronary artery disease.",
    "Confirm with standard clinical work-up: ECG, lipid profile, blood pressure, HbA1c, and where "
    "indicated stress testing or CT coronary calcium / angiography.",
    "Modifiable factors: stop smoking, regular aerobic exercise (about 150 min/week), a "
    "Mediterranean-style diet, healthy weight, limited alcohol, good sleep.",
    "Seek urgent care for chest pain, breathlessness or pain spreading to the arm or jaw.",
]
