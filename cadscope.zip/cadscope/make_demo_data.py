"""Generate SYNTHETIC RNA-seq cohorts so the pipeline can be demoed without downloading anything.

Five fake 'GSE' cohorts with different library depths / batch effects. CAD samples get a
modest up/down shift in the genes listed in cadscope/gene_info.py. This is NOT real biology;
swap in real NCBI GEO data for anything beyond a demo.

Usage:  python make_demo_data.py
"""
import os

import numpy as np
import pandas as pd

from cadscope.gene_info import PATHWAYS

rng = np.random.default_rng(42)
OUT = "data"
os.makedirs(OUT, exist_ok=True)

signal_genes = sorted({g for gs in PATHWAYS.values() for g in gs})
# Direction of effect: inflammation / lipid / thrombosis genes up in CAD, protective genes down.
down = {"NOS3", "KLF2", "KLF4", "ABCA1", "ABCG1", "APOA1", "LDLR", "BCL2", "NFE2L2", "THBD", "SOD2"}
effect = {g: (-0.2 if g in down else 0.2) for g in signal_genes}

n_background = 1800
background = [f"GENE{i:04d}" for i in range(n_background)]
all_genes = signal_genes + background
base_mean = rng.lognormal(mean=4.0, sigma=1.2, size=len(all_genes))

cohorts = {"GSE_DEMO1": (30, 30, 1.0), "GSE_DEMO2": (25, 25, 0.8), "GSE_DEMO3": (40, 30, 1.3),
           "GSE_DEMO4": (20, 20, 0.9), "GSE_DEMO5": (35, 35, 1.1)}


def simulate(n_ctrl, n_cad, depth, batch_sd=0.25, signal=1.0):
    labels = ["Control"] * n_ctrl + ["CAD"] * n_cad
    batch = rng.normal(0, batch_sd, size=len(all_genes))      # cohort-specific gene bias
    cols = {}
    for i, lab in enumerate(labels):
        log_mu = np.log(base_mean) + batch
        if lab == "CAD":
            for g, e in effect.items():
                log_mu[all_genes.index(g)] += e * signal
        lib = depth * rng.lognormal(0, 0.2)
        mu = np.exp(log_mu) * lib
        # Negative-binomial counts (dispersion 0.2)
        r = 1 / 0.2
        cols[f"S{i + 1:03d}"] = rng.negative_binomial(r, r / (r + mu))
    return pd.DataFrame(cols, index=all_genes), labels


for name, (nc, nd, depth) in cohorts.items():
    counts, labels = simulate(nc, nd, depth)
    counts.index.name = "gene"
    counts.to_csv(f"{OUT}/{name}_counts.csv")
    pd.DataFrame({"sample": counts.columns, "label": labels}).to_csv(f"{OUT}/{name}_meta.csv", index=False)

# A small "patient upload" file the app can be tested with (3 CAD-like, 3 control-like).
counts, labels = simulate(3, 3, 1.0)
counts.columns = [f"PATIENT_{l}_{i + 1}" for i, l in enumerate(labels)]
counts.index.name = "gene"
counts.to_csv("sample_upload.csv")

print(f"Wrote {len(cohorts)} synthetic cohorts to {OUT}/ and sample_upload.csv")
