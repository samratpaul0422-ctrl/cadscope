"""Train the CAD classifier from several RNA-seq datasets.

Expected layout (one pair of files per dataset, e.g. downloaded from NCBI GEO):

    data/GSE_A_counts.csv   genes (rows, symbols) x samples (columns), raw counts
    data/GSE_A_meta.csv     columns: sample, label   (label: CAD / Control, or 1 / 0)

Usage:
    python train.py --data-dir data --out models/cad_model.joblib --k 200
"""
import argparse
import glob
import json
import os

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from cadscope.common import load_counts, log_cpm

POSITIVE = {"cad", "case", "disease", "patient", "1", "true", "mi", "stemi", "atherosclerosis"}


def to_binary(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin(POSITIVE).astype(int)


def load_dataset(counts_path: str):
    meta_path = counts_path.replace("_counts.csv", "_meta.csv")
    counts = load_counts(counts_path)
    meta = pd.read_csv(meta_path).set_index("sample")
    shared = [s for s in counts.columns if s in meta.index]
    if not shared:
        raise ValueError(f"No overlapping sample IDs between {counts_path} and {meta_path}")
    x = log_cpm(counts[shared]).T            # samples x genes
    y = to_binary(meta.loc[shared, "label"])
    return x, y


def build_pipeline(k: int, n_features: int) -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            ("select", SelectKBest(f_classif, k=min(k, n_features))),
            ("clf", LogisticRegression(C=0.05, max_iter=2000, class_weight="balanced")),
        ]
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--out", default="models/cad_model.joblib")
    ap.add_argument("--k", type=int, default=200, help="number of genes kept")
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.data_dir, "*_counts.csv")))
    if len(files) < 2:
        raise SystemExit("Need at least 2 datasets (*_counts.csv + *_meta.csv) in --data-dir")

    datasets = {}
    for f in files:
        name = os.path.basename(f).replace("_counts.csv", "")
        datasets[name] = load_dataset(f)
        x, y = datasets[name]
        print(f"[load] {name}: {x.shape[0]} samples, {x.shape[1]} genes, {y.sum()} CAD")

    # Keep only genes present in every dataset, so the model is portable across them.
    genes = sorted(set.intersection(*[set(x.columns) for x, _ in datasets.values()]))
    print(f"[genes] {len(genes)} genes shared across all datasets")
    for n in datasets:
        x, y = datasets[n]
        datasets[n] = (x[genes], y)

    # Leave-one-dataset-out validation: train on N-1 cohorts, test on the held-out cohort.
    # This is the honest estimate, because it includes batch / platform shift.
    report = {}
    for held in datasets:
        tr = [n for n in datasets if n != held]
        x_tr = pd.concat([datasets[n][0] for n in tr])
        y_tr = pd.concat([datasets[n][1] for n in tr])
        x_te, y_te = datasets[held]
        pipe = build_pipeline(args.k, len(genes)).fit(x_tr.values, y_tr.values)
        auc = roc_auc_score(y_te, pipe.predict_proba(x_te.values)[:, 1])
        report[held] = round(float(auc), 3)
        print(f"[LODO] held-out {held}: AUC = {auc:.3f}")
    report["mean_auc"] = round(float(np.mean(list(report.values()))), 3)
    print(f"[LODO] mean AUC = {report['mean_auc']}")

    # Final model on everything.
    x_all = pd.concat([d[0] for d in datasets.values()])
    y_all = pd.concat([d[1] for d in datasets.values()])
    pipe = build_pipeline(args.k, len(genes)).fit(x_all.values, y_all.values)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    bundle = {
        "pipeline": pipe,
        "genes": genes,
        "train_means": x_all.mean().to_dict(),
        "validation": report,
        "datasets": list(datasets),
    }
    joblib.dump(bundle, args.out)
    with open(os.path.splitext(args.out)[0] + "_report.json", "w") as fh:
        json.dump(report, fh, indent=2)

    sel = np.array(genes)[pipe.named_steps["select"].get_support()]
    coef = pd.Series(pipe.named_steps["clf"].coef_[0], index=sel).sort_values()
    print("\nTop genes pushing toward CAD:", ", ".join(coef.tail(8).index[::-1]))
    print("Top genes pushing toward Control:", ", ".join(coef.head(8).index))
    print(f"\nSaved model to {args.out}")


if __name__ == "__main__":
    main()
