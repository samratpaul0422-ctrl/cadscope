"""CADScope: Streamlit front-end. Run with:  streamlit run app.py"""
import os

import joblib
import pandas as pd
import streamlit as st

from cadscope.common import load_counts, pathway_summary, predict, risk_tier
from cadscope.gene_info import GENERAL_PRECAUTIONS, PATHWAY_ADVICE

MODEL_PATH = "models/cad_model.joblib"

st.set_page_config(page_title="CADScope", page_icon="🫀", layout="wide")
st.title("🫀 CADScope: RNA-seq coronary artery disease risk prototype")
st.warning(
    "Research / hackathon prototype. Not a medical device and not a diagnosis. "
    "Results must be interpreted by a clinician alongside standard cardiac work-up."
)

if not os.path.exists(MODEL_PATH):
    st.error("No trained model found. Run `python train.py` first (see README).")
    st.stop()


@st.cache_resource
def get_model():
    return joblib.load(MODEL_PATH)


bundle = get_model()

with st.sidebar:
    st.header("Model info")
    st.write(f"Trained on: {', '.join(bundle['datasets'])}")
    st.write(f"Genes in model: {len(bundle['genes'])}")
    st.write(f"Leave-one-cohort-out AUC: **{bundle['validation']['mean_auc']}**")
    st.caption("AUC is measured on cohorts the model never saw during training.")

st.subheader("1. Upload RNA-seq raw counts")
st.caption("CSV/TSV, genes (HGNC symbols) as rows, samples as columns, raw integer counts.")
upload = st.file_uploader("Counts matrix", type=["csv", "tsv", "txt"])

if upload is None:
    st.info("Upload a file to begin. Try `sample_upload.csv` from the repo.")
    st.stop()

counts = load_counts(upload)
st.write(f"Loaded **{counts.shape[1]} samples** x **{counts.shape[0]} genes**")

prob, contrib, coverage = predict(bundle, counts)
if coverage < 0.5:
    st.error(
        f"Only {coverage:.0%} of the model's genes were found in your file. Check that gene "
        "identifiers are HGNC symbols (not Ensembl IDs); scores below are unreliable."
    )
elif coverage < 0.9:
    st.warning(f"{coverage:.0%} of model genes found; missing genes were imputed with training means.")

st.subheader("2. Molecular CAD score per sample")
result = pd.DataFrame({"cad_score": prob.round(3), "risk_tier": prob.map(risk_tier)})
c1, c2 = st.columns([1, 1])
c1.dataframe(result, use_container_width=True)
c2.bar_chart(prob)

sample = st.selectbox("3. Inspect a sample", result.index)
p = float(prob[sample])
m1, m2 = st.columns(2)
m1.metric("CAD molecular score", f"{p:.2f}")
m2.metric("Risk tier", risk_tier(p))

left, right = st.columns(2)
with left:
    st.markdown("**Top genes driving this score**")
    row = contrib.loc[sample]
    top = pd.concat([row.sort_values().head(8), row.sort_values().tail(8)]).sort_values()
    st.bar_chart(top)
    st.caption("Positive = pushes toward CAD, negative = toward control.")
with right:
    st.markdown("**Pathway-level view**")
    paths = pathway_summary(row)
    if paths.empty:
        st.write("No annotated pathway genes were among the model's selected genes.")
    else:
        st.dataframe(paths, use_container_width=True, hide_index=True)

st.subheader("4. Suggested follow-up (for clinician review)")
if p >= 0.33 and not paths.empty:
    for _, r in paths[paths.net_contribution > 0].head(3).iterrows():
        st.markdown(f"- **{r.pathway}**: {PATHWAY_ADVICE[r.pathway]}")
else:
    st.write("No pathway is strongly pushing risk upward for this sample.")
st.markdown("**General precautions**")
for line in GENERAL_PRECAUTIONS:
    st.markdown(f"- {line}")

st.download_button(
    "Download results (CSV)",
    result.join(contrib).to_csv().encode(),
    file_name="cadscope_results.csv",
)
