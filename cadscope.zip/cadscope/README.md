# 🫀 CADScope: RNA-seq → gene expression → CAD risk (hackathon prototype)

Upload an RNA-seq raw-count matrix → CADScope normalises it, scores each sample with a model trained on
public NCBI GEO cohorts, shows **which genes and biological pathways drive the score**, and suggests
follow-up for a clinician.

> **Not a medical device.** Research prototype only. Never use it to diagnose or rule out coronary artery disease.

## How it works

```
raw counts ──► log2-CPM normalisation ──► gene matching to training genes
        ──► StandardScaler ──► SelectKBest (top-k genes) ──► Logistic Regression
        ──► CAD molecular score (0-1) ──► Low / Intermediate / High tier
        ──► per-gene contribution (coef x z-score) ──► pathway roll-up ──► follow-up notes
```

- `cadscope/common.py`: loading, normalisation, prediction, pathway summary
- `cadscope/gene_info.py`: curated CAD pathways (lipid, inflammation, endothelium, thrombosis, ECM, oxidative stress)
- `train.py`: trains on several cohorts, validates with **leave-one-dataset-out** AUC
- `app.py`: Streamlit UI
- `make_demo_data.py`: synthetic cohorts so you can demo without downloading anything

## Quick start (5 minutes, synthetic data)

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python make_demo_data.py          # creates data/ and sample_upload.csv
python train.py                   # creates models/cad_model.joblib
streamlit run app.py              # opens http://localhost:8501, upload sample_upload.csv
```

The synthetic data only proves the pipeline works. Its AUC says nothing about real biology.

## Using real NCBI GEO datasets

1. Go to https://www.ncbi.nlm.nih.gov/geo/ and search e.g. `coronary artery disease RNA-seq blood`,
   then filter **Study type: Expression profiling by high throughput sequencing** and **Organism: Homo sapiens**.
2. Pick 4-5 cohorts of the **same tissue** (e.g. all whole blood or all PBMC). Mixing tissues will hurt badly.
3. For each, download the raw count matrix from the *Supplementary files* section (often `*_counts.txt.gz`).
   If only FASTQ is provided, you need an aligner/quantifier (STAR + featureCounts, or Salmon); skip those series for a hackathon.
4. Build a metadata file from the sample table (GEO "Series Matrix" or the sample characteristics):
   ```
   sample,label
   GSM123,CAD
   GSM124,Control
   ```
5. Save as `data/<name>_counts.csv` (genes x samples) and `data/<name>_meta.csv`. Gene IDs must be **HGNC symbols**;
   if you have Ensembl IDs, map them with `mygene` or `biomaRt` first.
6. Re-run `python train.py`.

Be careful with labels. Definitions of "CAD" differ between studies (stable CAD vs. myocardial infarction vs. controls with
risk factors). Harmonise them deliberately and write your choices in the README. Check each dataset's licence and
data-use terms.

## Honest limitations (put these in your pitch, judges like this)

- Small public cohorts + batch effects → real performance will be far below the synthetic demo. Report the
  leave-one-dataset-out AUC, not training accuracy.
- The score is a **probability-like signal, not a calibrated risk** and not a measure of angiographic severity. "Tier" is a simple threshold.
- Whole-blood expression reflects systemic inflammation and cell-type mix, which can confound CAD signals.
- Pathway annotation is a small hand-curated list. Replace it with MSigDB/Reactome via `gseapy` for a stronger version.

## Ideas to extend

- Differential expression (PyDESeq2) tab before modelling
- Pathway enrichment with `gseapy` (Hallmark / KEGG)
- Cell-type deconvolution, batch correction (ComBat / `pycombat`), SHAP explanations
- Calibration curve and a clinical-covariate model (age, sex, lipids) combined with expression

## Publish on GitHub

```bash
cd cadscope
git init
git add .
git commit -m "Initial commit: CADScope RNA-seq CAD prototype"
git branch -M main
# create an empty repo on github.com (no README), then:
git remote add origin https://github.com/<your-username>/cadscope.git
git push -u origin main
```

Or with the GitHub CLI: `gh repo create cadscope --public --source=. --push`.

Optional free hosting for the demo: push to GitHub, then deploy at https://share.streamlit.io (select the repo and `app.py`).
Because `models/` and `data/` are git-ignored, either remove those two lines from `.gitignore` and commit a small demo
model, or have the app run `make_demo_data.py` and `train.py` on first launch.

## License

Add an MIT `LICENSE` file (GitHub → Add file → Create new file → type `LICENSE` → choose a template).
